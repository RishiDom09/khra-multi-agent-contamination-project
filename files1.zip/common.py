"""
Shared helpers for the Algoverse contamination experiments.

Everything the two architectures need lives here:
  - loading MINT from Hugging Face
  - building the uninformed vs misinformed prompt
  - stripping qwen3 thinking tags and pulling out the final answer letter
  - a retrying Groq client so free tier rate limits do not kill a run
"""

import os
import re
import time
import random

from datasets import load_dataset
from langchain_groq import ChatGroq


MODEL_NAME = "qwen/qwen3-32b"
MINT_REPO = "jonasbecker/MINT"

# The nine MINT intent categories.
CATEGORIES = [
    "neutral", "clickbait", "hoax", "rumor", "satire",
    "propaganda", "framing", "conspiracy", "other",
]


# ----------------------------------------------------------------------
# LLM
# ----------------------------------------------------------------------

def get_llm(temperature=0.0):
    if not os.environ.get("GROQ_API_KEY"):
        raise RuntimeError(
            "GROQ_API_KEY is not set. In PowerShell run:\n"
            '  $env:GROQ_API_KEY="your_key_here"'
        )
    return ChatGroq(model=MODEL_NAME, temperature=temperature)


def call_llm(llm, prompt, max_retries=6):
    """Call the model, retrying with backoff on rate limits."""
    delay = 5
    for attempt in range(max_retries):
        try:
            return strip_thinking(llm.invoke(prompt).content)
        except Exception as e:
            msg = str(e).lower()
            if "rate" in msg or "429" in msg or "quota" in msg:
                print(f"    rate limited, waiting {delay}s")
                time.sleep(delay)
                delay = min(delay * 2, 90)
            elif attempt == max_retries - 1:
                raise
            else:
                print(f"    error: {e}, retrying")
                time.sleep(delay)
    raise RuntimeError("gave up after repeated failures")


def strip_thinking(text):
    """qwen3 emits <think>...</think>. Remove it before parsing."""
    return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()


# ----------------------------------------------------------------------
# MINT loading
# ----------------------------------------------------------------------

def inspect_mint(subset=None):
    """Print MINT's real schema. Run this once before anything else."""
    ds = _raw_mint(subset)
    print("Columns:", ds.column_names)
    print("Rows:", len(ds))
    print("\nFirst row:")
    row = ds[0]
    for k, v in row.items():
        preview = str(v)
        if len(preview) > 300:
            preview = preview[:300] + " ..."
        print(f"  {k}: {preview}")
    return ds


def _raw_mint(subset=None):
    try:
        if subset:
            return load_dataset(MINT_REPO, subset, split="train")
        return load_dataset(MINT_REPO, split="train")
    except Exception:
        # Some configs expose "test" instead of "train".
        if subset:
            return load_dataset(MINT_REPO, subset, split="test")
        return load_dataset(MINT_REPO, split="test")


def _first_present(row, names):
    for n in names:
        if n in row and row[n] not in (None, ""):
            return row[n]
    return None


def load_mint(subset="winogrande", n=100, category="hoax", seed=42):
    """
    Return a list of dicts shaped like:
      {id, question, options: [..], gold, misinformation}

    Field detection is deliberately loose because the exact MINT column
    names are confirmed by running inspect_mint() first. If a field is not
    found, this raises with the columns printed so you can adjust the lists
    below in one place.
    """
    ds = _raw_mint(subset)

    rows = list(range(len(ds)))
    random.Random(seed).shuffle(rows)

    out = []
    for idx in rows:
        row = ds[idx]

        question = _first_present(row, [
            "question", "sentence", "scenario", "input", "query", "prompt",
        ])

        options = _first_present(row, ["options", "choices", "answer_choices"])
        if options is None:
            o1 = _first_present(row, ["option1", "optionA", "a"])
            o2 = _first_present(row, ["option2", "optionB", "b"])
            options = [o for o in (o1, o2) if o is not None]
        if isinstance(options, str):
            options = [options]

        gold = _first_present(row, [
            "answer", "correct_answer", "label", "gold", "solution",
        ])

        # Misinformation may be a dict keyed by category, or one column
        # per category, or a single column plus a category label.
        misinfo = None
        if "misinformation" in row:
            m = row["misinformation"]
            if isinstance(m, dict):
                misinfo = m.get(category)
            else:
                if row.get("category", row.get("intent")) == category:
                    misinfo = m
                else:
                    continue
        elif category in row:
            misinfo = row[category]

        if not question or not gold or not misinfo:
            continue

        out.append({
            "id": f"{subset}-{idx}",
            "question": str(question),
            "options": [str(o) for o in options] if options else [],
            "gold": str(gold),
            "misinformation": str(misinfo),
        })

        if len(out) >= n:
            break

    if not out:
        raise RuntimeError(
            "Could not map MINT fields. Columns are:\n"
            f"  {ds.column_names}\n"
            "Run  python inspect_mint.py  and tell Claude what it prints."
        )
    return out


# ----------------------------------------------------------------------
# Prompts and scoring
# ----------------------------------------------------------------------

def letters(sample):
    return [chr(ord("A") + i) for i in range(len(sample["options"]))]


def question_block(sample):
    text = sample["question"]
    if sample["options"]:
        lines = [
            f"{L}) {opt}"
            for L, opt in zip(letters(sample), sample["options"])
        ]
        text += "\n\nAnswer Choices:\n" + "\n".join(lines)
    return text


def context_block(sample, misinformed):
    """
    The only difference between an uninformed and a misinformed agent.
    The agent is never told the extra information might be false, which
    is the benign setup used by Becker et al. 2026.
    """
    if not misinformed:
        return ""
    return f"\n\nYou have this extra information:\n{sample['misinformation']}\n"


def gold_letter(sample):
    """Normalise the gold answer to a letter where possible."""
    g = sample["gold"].strip()
    if len(g) == 1 and g.upper() in letters(sample):
        return g.upper()
    if g in ("1", "2", "3", "4"):
        return chr(ord("A") + int(g) - 1)
    for L, opt in zip(letters(sample), sample["options"]):
        if opt.strip().lower() == g.lower():
            return L
    return g


ANSWER_RE = re.compile(r"\b(?:answer|choice)\b[^A-Za-z]{0,12}([A-D])\b", re.I)


def extract_answer(text, sample):
    """Pull the final answer letter out of an agent's reply."""
    valid = set(letters(sample)) or {"A", "B", "C", "D"}

    matches = ANSWER_RE.findall(text)
    if matches:
        cand = matches[-1].upper()
        if cand in valid:
            return cand

    # Otherwise take the last standalone capital letter in the reply.
    standalone = re.findall(r"(?<![A-Za-z])([A-D])(?![A-Za-z])", text)
    for cand in reversed(standalone):
        if cand.upper() in valid:
            return cand.upper()

    return ""


ANSWER_INSTRUCTION = (
    "End your reply with a single line in exactly this format:\n"
    "ANSWER: X\n"
    "where X is the letter of your chosen option. Nothing after that line."
)
