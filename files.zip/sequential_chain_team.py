"""
Sequential Chain Team
======================
Agents run in a fixed order: Researcher -> Writer -> Editor -> END.
Each agent reads the shared state, does its job, and passes updated
state to the next node. No branching, no decisions, just a straight
pipeline.

Setup:
    pip install langgraph langchain-groq
    export GROQ_API_KEY=your_key_here

Run:
    python sequential_chain_team.py
"""

import os
from typing import TypedDict
from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq


# ---- Shared state passed between nodes ----
class State(TypedDict):
    question: str
    research_notes: str
    draft: str
    final_answer: str


# ---- Model used by every agent (swap model name if needed) ----
llm = ChatGroq(model="llama-3.3-70b-versatile", temperature=0)


# ---- Node 1: Researcher ----
def researcher(state: State) -> State:
    prompt = (
        f"You are a researcher. Gather key facts and considerations "
        f"needed to answer this question. Be concise, bullet points only.\n\n"
        f"Question: {state['question']}"
    )
    response = llm.invoke(prompt)
    state["research_notes"] = response.content
    return state


# ---- Node 2: Writer ----
def writer(state: State) -> State:
    prompt = (
        f"You are a writer. Using the research notes below, write a clear "
        f"draft answer to the question.\n\n"
        f"Question: {state['question']}\n\n"
        f"Research notes:\n{state['research_notes']}"
    )
    response = llm.invoke(prompt)
    state["draft"] = response.content
    return state


# ---- Node 3: Editor ----
def editor(state: State) -> State:
    prompt = (
        f"You are an editor. Tighten and polish this draft into a final "
        f"answer. Fix any unclear phrasing.\n\n"
        f"Draft:\n{state['draft']}"
    )
    response = llm.invoke(prompt)
    state["final_answer"] = response.content
    return state


# ---- Build the graph ----
def build_graph():
    graph = StateGraph(State)

    graph.add_node("researcher", researcher)
    graph.add_node("writer", writer)
    graph.add_node("editor", editor)

    graph.set_entry_point("researcher")
    graph.add_edge("researcher", "writer")
    graph.add_edge("writer", "editor")
    graph.add_edge("editor", END)

    return graph.compile()


if __name__ == "__main__":
    app = build_graph()

    result = app.invoke({
        "question": "What causes the seasons on Earth?",
        "research_notes": "",
        "draft": "",
        "final_answer": "",
    })

    print("\n=== RESEARCH NOTES ===")
    print(result["research_notes"])
    print("\n=== DRAFT ===")
    print(result["draft"])
    print("\n=== FINAL ANSWER ===")
    print(result["final_answer"])
