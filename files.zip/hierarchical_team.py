"""
Hierarchical Team
==================
One supervisor agent decides which worker should act next, based on
the current state. Workers do their job and report back to the
supervisor. The supervisor loops until it decides the task is done.

This differs from Sequential Chain Team because the order isn't fixed:
the supervisor makes that call dynamically, and could send work back
to the same worker again, skip a worker, or finish early.

Setup:
    pip install langgraph langchain-groq
    export GROQ_API_KEY=your_key_here

Run:
    python hierarchical_team.py
"""

import os
from typing import TypedDict, Literal
from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq

# ---- Shared state passed between nodes ----
class State(TypedDict):
    question: str
    research_notes: str
    draft: str
    next_step: str  # what the supervisor decided last


llm = ChatGroq(model="llama-3.3-70b-versatile", temperature=0)

WORKERS = ["researcher", "writer"]


# ---- Supervisor: decides who goes next ----
def supervisor(state: State) -> State:
    prompt = (
        f"You are a supervisor managing two workers: 'researcher' and 'writer'.\n\n"
        f"Question: {state['question']}\n"
        f"Research notes so far: {state['research_notes'] or '(none yet)'}\n"
        f"Draft so far: {state['draft'] or '(none yet)'}\n\n"
        f"Decide what should happen next. Reply with exactly one word:\n"
        f"'researcher' if research notes are missing or incomplete,\n"
        f"'writer' if research is done but draft is missing,\n"
        f"'FINISH' if the draft is complete and answers the question well."
    )
    response = llm.invoke(prompt)
    decision = response.content.strip().lower()

    if "finish" in decision:
        state["next_step"] = "FINISH"
    elif "writer" in decision:
        state["next_step"] = "writer"
    else:
        state["next_step"] = "researcher"

    return state


# ---- Worker: Researcher ----
def researcher(state: State) -> State:
    prompt = (
        f"You are a researcher. Gather key facts needed to answer this "
        f"question. Be concise, bullet points only.\n\n"
        f"Question: {state['question']}"
    )
    response = llm.invoke(prompt)
    state["research_notes"] = response.content
    return state


# ---- Worker: Writer ----
def writer(state: State) -> State:
    prompt = (
        f"You are a writer. Using the research notes below, write a clear "
        f"final answer to the question.\n\n"
        f"Question: {state['question']}\n\n"
        f"Research notes:\n{state['research_notes']}"
    )
    response = llm.invoke(prompt)
    state["draft"] = response.content
    return state


# ---- Routing function: reads the supervisor's last decision ----
def route(state: State) -> Literal["researcher", "writer", "__end__"]:
    if state["next_step"] == "FINISH":
        return END
    return state["next_step"]


# ---- Build the graph ----
def build_graph():
    graph = StateGraph(State)

    graph.add_node("supervisor", supervisor)
    graph.add_node("researcher", researcher)
    graph.add_node("writer", writer)

    graph.set_entry_point("supervisor")

    graph.add_conditional_edges("supervisor", route, {
        "researcher": "researcher",
        "writer": "writer",
        END: END,
    })

    # After a worker runs, control always goes back to the supervisor
    graph.add_edge("researcher", "supervisor")
    graph.add_edge("writer", "supervisor")

    return graph.compile()


if __name__ == "__main__":
    app = build_graph()

    result = app.invoke({
        "question": "What causes the seasons on Earth?",
        "research_notes": "",
        "draft": "",
        "next_step": "",
    })

    print("\n=== RESEARCH NOTES ===")
    print(result["research_notes"])
    print("\n=== FINAL DRAFT ===")
    print(result["draft"])
